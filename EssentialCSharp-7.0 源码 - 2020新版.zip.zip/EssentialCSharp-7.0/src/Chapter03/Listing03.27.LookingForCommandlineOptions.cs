namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_27
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // ...
            if(args[0][0] == '-')
            {
                // This parameter is an option
            }
        }
    }
}
