namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_18
{
    public class Program
    {
        public static void Main()
        {
            string[] languages = new string[9] {
                "C#", "COBOL", "Java",
                "C++", "Visual Basic", "Pascal",
                "Fortran", "Lisp", "J#"};
            // Retrieve 5th item in languages array (Java)
            string language = languages[4];
        }
    }
}
