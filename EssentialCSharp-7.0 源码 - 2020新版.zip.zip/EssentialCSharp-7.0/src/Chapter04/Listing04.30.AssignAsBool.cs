#pragma warning disable CS0168 // Variable is declared but never used
#pragma warning disable CS0219 // Variable is assigned but its value is never used
namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_30
{
    public class Program
    {
        public static void Main()
        {
            bool result = 70 > 7;
        }
    }
}
