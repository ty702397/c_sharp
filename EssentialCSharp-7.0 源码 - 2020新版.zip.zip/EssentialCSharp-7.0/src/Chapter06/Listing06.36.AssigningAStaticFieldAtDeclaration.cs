namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_36
{
    class Employee
    {
        // ...
        public static int NextId = 42;
        // ...
    }
}
