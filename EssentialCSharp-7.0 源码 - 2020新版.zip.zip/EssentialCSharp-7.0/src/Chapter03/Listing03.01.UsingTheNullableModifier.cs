namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_01
{
    public class Program
    {
        public static void Main()
        {
            int? count = null;
            do
            {
                // ... 
            }
            while(count == null);
        }
    }
}
