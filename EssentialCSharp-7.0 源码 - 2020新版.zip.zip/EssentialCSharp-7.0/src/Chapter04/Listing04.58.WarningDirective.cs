namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_58
{
    public class Program
    {
        public static void Main()
        {
#warning "Same move allowed multiple times."
        }
    }
}
