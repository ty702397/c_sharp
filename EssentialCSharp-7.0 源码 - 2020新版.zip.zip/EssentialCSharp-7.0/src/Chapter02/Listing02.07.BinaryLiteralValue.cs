namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_07
{
    public class Program
    {
        public static void Main()
        {
            // Display the value 42 using a binary literal
            System.Console.WriteLine(0b101010);
        }
    }
}
