namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter12.Listing12_10
{
    using System;

    // ERROR: 'ComparisonHandler' cannot 
    // inherit from special class 'System.Delegate'
    //public class ComparisonHandler : System.Delegate
    //{
    //    ...
    //}
}
