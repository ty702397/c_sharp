﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_01
{
    using System;

    public class Program
    {
        public static void Main()
        {
            System.Console.WriteLine("No output in this example");
        }
    }

    class Employee
    {
    }

}
