namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_20
{
    public class Program
    {
        public static void Main()
        {
            long longNumber = 50918309109;
            int intNumber = (int)longNumber;
        }
    }
}
