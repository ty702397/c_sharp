namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_28
{
    public class Program
    {
        public static void Main()
        {
            bool boolean = true;
            string text = boolean.ToString();
            // Display "True"
            System.Console.WriteLine(text);
        }
    }
}
