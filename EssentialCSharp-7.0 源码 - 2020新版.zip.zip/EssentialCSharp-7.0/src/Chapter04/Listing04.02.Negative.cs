namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_02
{
    public class Program
    {
        public static void Main()
        {
            //National Debt to the Penny
            decimal debt = -18125876697430.99M;

            System.Console.WriteLine(debt);
        }
    }
}
