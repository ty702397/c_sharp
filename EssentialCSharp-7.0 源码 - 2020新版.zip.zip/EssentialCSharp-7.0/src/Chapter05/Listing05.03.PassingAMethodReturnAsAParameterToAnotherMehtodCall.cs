namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter05.Listing05_03
{
    public class Program
    {
        public static void Main()
        {
            System.Console.Write("Enter your first name: ");
            System.Console.WriteLine("Hello {0}!",
                System.Console.ReadLine());
        }
    }
}
