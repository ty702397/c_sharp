﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter10.Listing10_13
{
    public struct Coordinate
    {
        // ...
    }

    public struct Latitude
    {
        // ...
    }

    public struct Longitude
    {
        // ...
    }

    public struct Arc
    {
        // ...
    }
}