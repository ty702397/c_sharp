namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_13
{
    public class DuelOfWits
    {
        public static void Main()
        {
            System.Console.Write(
                "\"Truly, you have a dizzying intellect.\"");
            System.Console.Write("\n\"Wait 'til I get going!\"\n");
        }
    }
}
