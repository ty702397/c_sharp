namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_07
{
    public class Program
    {
        public static void Main()
        {
            string[] languages = { "C#", "COBOL", "Java",
                "C++", "Visual Basic", "Pascal",
                "Fortran", "Lisp", "J#" };
        }
    }
}
