﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter07.Listing07_03
{
    public class PdaItem : object
    {
        // ...
    }
    public class Appointment : PdaItem
    {
        // ...
    }
    public class Contact : PdaItem
    {
        // ...
    }
    public class Customer : Contact
    {
        // ...
    }
}
