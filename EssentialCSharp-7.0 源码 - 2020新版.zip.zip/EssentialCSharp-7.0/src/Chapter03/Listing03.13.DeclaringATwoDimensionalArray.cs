namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_13
{
    public class Program
    {
        public static void Main()
        {
            int[,] cells = new int[3,3];
        }
    }
}
