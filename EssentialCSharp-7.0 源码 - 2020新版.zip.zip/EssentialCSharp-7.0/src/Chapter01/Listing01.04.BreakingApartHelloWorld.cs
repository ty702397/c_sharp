namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_04
{
    public class Program//Class definition
    {
        public static void Main()//Method declaration
        {
            System.Console.WriteLine("Hello, My name is Inigo Montoya");//This is the statement
        }//This is the end of the method
    }//end of the class definition
}
