namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_10
{
    public class Program
    {
        public static void Main()
        {
            int x = 123;
            x = x + 2;
        }
    }
}
