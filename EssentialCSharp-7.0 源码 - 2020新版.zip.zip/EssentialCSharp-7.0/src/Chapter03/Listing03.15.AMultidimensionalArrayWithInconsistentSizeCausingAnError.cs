namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_15
{
    public class Program
    {
        public static void Main()
        {
            // ERROR: Each dimension must be consistently sized
            /*
            int[,] cells = {
                {1, 0, 2, 0},
                {1, 2, 0},
                {1, 2},
                {1}
            };
            */
        }
    }
}
