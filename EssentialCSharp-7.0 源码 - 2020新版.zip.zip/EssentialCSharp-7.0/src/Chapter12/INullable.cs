﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter12.Listing12_24
{
    public interface INullable
    {
        bool IsNull { get; }
    }
}
