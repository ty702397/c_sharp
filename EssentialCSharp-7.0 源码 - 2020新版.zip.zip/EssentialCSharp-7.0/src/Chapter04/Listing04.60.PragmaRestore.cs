namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_60
{
    public class Program
    {
        public static void Main()
        {
#pragma warning restore 1030
        }
    }
}
