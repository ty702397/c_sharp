﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter10.Listing10_14
{
    // Define the namespace AddisonWesley
    namespace AddisonWesley
    {
        class Program
        {
            // ...
        }
    }
    // End of AddisonWesley namespace declaration 
}