namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_22
{
    public class Program
    {
        public static void Main()
        {
            string[] languages = new string[9];
            // ...
            System.Console.WriteLine(
                $"There are {languages.Length} languages in the array.");
        }
    }
}
