﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_01
{
    public class Program
    {
        public static void Main()
        {
            System.Console.WriteLine(42);
            System.Console.WriteLine(1.618034);
        }
    }
}
