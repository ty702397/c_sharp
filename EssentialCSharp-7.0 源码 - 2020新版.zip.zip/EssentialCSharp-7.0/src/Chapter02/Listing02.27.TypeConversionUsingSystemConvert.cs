namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_27
{
    public class Program
    {
        public static void Main()
        {
            string middleCText = "261.626";
            double middleC = System.Convert.ToDouble(middleCText);
            bool boolean = System.Convert.ToBoolean(middleC);
        }
    }
}
